  for (let i = 0; i <= 5; i++) { // 0 < +
    console.log(i);
  }
  for (let i = 5; i >= 0; i--) { // 5
    console.log(i);
  }
  for (let i = str.length - 1; i >= 0; i--) {
    reversed = reversed + str[i];
  }
  for (let i = 0; i < arr.length; i++) {
     sum += arr[i];
  }
  for (let i = str.length - 1; i >= 0; i--) {
    reversed = reversed + str[i];
  }