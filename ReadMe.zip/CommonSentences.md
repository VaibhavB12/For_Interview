It ensures 
It defines 
It specifies
... is done using  
... is done through

In one of our project i have used ...
In my recent ecommerce project i have used ...
this is why
in order to
in the respective controllers
update
document itself
refers to the
wont be able to
pull out properties