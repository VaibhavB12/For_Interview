### **Key Points on TypeScript (TS) vs JavaScript (JS)**  

#### **1. What is TypeScript?**  
- TypeScript is a **strongly typed** language, whereas JavaScript is **loosely typed**.  
- TypeScript is a **superset of JavaScript**, meaning all JavaScript code is valid TypeScript code.  
- TypeScript adds features like **type system, enums, generics, and interfaces** that JavaScript does not have.  

#### **2. Why Use TypeScript Over JavaScript?**  
- **Stronger Type Checking:** Helps catch errors at compile time instead of runtime.  
- **Object-Oriented Features:** Supports **classes, interfaces, and inheritance** for better code organization.  
- **Improved Code Readability & Maintainability:** Enforces strict types, reducing unexpected errors.  

#### **3. Does the Browser Understand TypeScript?**  
- No, the browser only understands JavaScript.  
- TypeScript code is **compiled** into JavaScript before running in the browser.  

---

### **TypeScript Features & Code Examples**  

#### **4. TypeScript is Strongly Typed**  
- In TypeScript, variables have **fixed types**.  
- Example:  
  ```typescript
  let name: string = "John";  
  name = 25; // ❌ This will cause a compile-time error.
  ```  
- In JavaScript, the same variable can hold different types, which can cause **runtime errors**.  

#### **5. TypeScript is a Superset of JavaScript**  
- Any valid JavaScript code will work in TypeScript.  
- Example:  
  ```typescript
  let message = "Hello"; // This is valid JavaScript and also valid TypeScript.
  ```

#### **6. Object-Oriented Features in TypeScript**  
- TypeScript supports **classes and object-oriented programming** like Java and C#.  
- Example:  
  ```typescript
  class Person {
      name: string;
      constructor(name: string) {
          this.name = name;
      }
  }
  ```

#### **7. TypeScript Detects Errors at Compile Time**  
- JavaScript detects errors only when the code runs.  
- TypeScript finds errors before running the code, making it more **reliable**.  

---

### **Installing TypeScript & Checking Version**  
#### **8. Install TypeScript**  
- Run this command:  
  ```
  npm install -g typescript
  ```
- To check the installed version:  
  ```
  tsc --version
  ```

---

### **Differences Between `let` and `var`**  
#### **9. Scope Difference**  
- `var` has **function scope**, meaning it is available inside the function but not limited to a block.  
- `let` has **block scope**, meaning it is available only inside the `{}` block where it is declared.  
- Example:  
  ```typescript
  function test() {
      for (var i = 0; i < 3; i++) {
          console.log(i); // ✅ Works inside loop
      }
      console.log(i); // ✅ Still accessible (bad practice)
  }
  
  function test2() {
      for (let j = 0; j < 3; j++) {
          console.log(j); // ✅ Works inside loop
      }
      console.log(j); // ❌ Error: j is not defined
  }
  ```

---

### **Type Annotations in TypeScript**  
#### **10. What is Type Annotation?**  
- Type annotation **assigns a fixed type** to a variable or object.  
- If we assign a different type, **TypeScript gives a compile-time error**.  
- Example:  
  ```typescript
  let age: number = 25;
  age = "twenty-five"; // ❌ Error: Type 'string' is not assignable to type 'number'
  ```

---

### **Built-in (Primitive) & User-defined (Non-Primitive) Types**  
#### **11. Primitive (Built-in) Types**  
- Used for **simple values**:  
  - `string` → `"Hello"`  
  - `number` → `123`  
  - `boolean` → `true` / `false`  

#### **12. Non-Primitive (User-Defined) Types**  
- Used for **complex values**:  
  - `array` → `let numbers: number[] = [1, 2, 3];`  
  - `tuple` → `let person: [string, number] = ["Alice", 30];`  
  - `enum` → `enum Color { Red, Green, Blue }`  
  - `class` → `class Car { brand: string; constructor(brand: string) { this.brand = brand; } }`  

---

### **Conclusion**  
- TypeScript **improves JavaScript** by adding **strong typing, object-oriented features, and compile-time error checking**.  
- It helps **write better, more structured, and error-free code**.  
- TypeScript code needs to be **compiled** into JavaScript before running in a browser.


### **Key Points About TypeScript Variables & Data Types**  

1. **Variable Declaration**  
   - In TypeScript, you can declare variables using `let`, `var`, or `const`.  
   - `let` is preferred over `var` due to scope differences.  
   - `const` is used for values that should not change.  

2. **Type Annotation**  
   - Unlike JavaScript, TypeScript allows you to specify a variable’s data type using a colon (`:`).  
   - Example: `let a: number = 10;`  

3. **Default Type**  
   - If no type is assigned, TypeScript sets it as `any`, which allows any value.  

4. **JavaScript Compatibility**  
   - TypeScript compiles into JavaScript.  
   - JavaScript does not have strict type checking, while TypeScript does.  

5. **Compilation & Errors**  
   - TypeScript checks for type errors before running the code.  
   - If an incorrect value is assigned, TypeScript gives an error and won’t compile.  

6. **Constant Variables (`const`)**  
   - A `const` variable must be assigned a value when declared.  
   - Once assigned, its value cannot change.  

7. **Variable Naming Rules**  
   - Can contain letters (`a-z, A-Z`) and numbers (`0-9`).  
   - Cannot start with a number.  
   - Can include `_` (underscore) and `$` (dollar sign).  
   - Cannot contain spaces or special characters (except `_` and `$`).  

8. **Primitive Data Types in TypeScript**  
   - `number`, `string`, `boolean`, `null`, `undefined`, `symbol`, `bigint`.  

9. **Strict Type Checking**  
   - TypeScript enforces strict typing to prevent errors.  
   - Example: If a variable is declared as `number`, you cannot assign a `string` to it.  

10. **Hoisting & `var`**  
   - `var` behaves differently due to hoisting, which will be explained separately.  
   - It is recommended to use `let` and `const` instead of `var`.  




===========================================================================================================================
===========================================================================================================================
TYPESCRIPT NIRMAL :
JavaScript has "var" & "let" to declare a variable and "const" to declare a constant It is the same in TypeScript as well But in JavaScript you don't have a choice to explicitly decide the datatype
let a:number
console.log(a) // undefined
a = 5;
console.log(a) // 5
Syntax of variable declaration :
   let <variableName>:<datatype>=value
   const <variableName>:<datatype>=value
While defining the constant, you have to assign the value along with because later it won't allow you to assign.
A variable name can contain an alphabet or a number A variable name cannot contain spaces in between A variable name cannot start with a number

Primitive Data Types :
1.Numbers :
When we talk about numbers : Number or numeric value Hexadecimal Binary Octal in JavaScript / TypeScript, all of these fall under the numeric category.
When you declare a variable with a number — it means it can store any valid numeric value Like JavaScript, the very same number is also used to store float values So any number typed variable is by default — a floating—point value only.
let b:number = 0.1001
console.log(b) // 0.1001
Whether you give a floating point value or a decimal value it will work with the number datatype itself.
let b:number=0b111010; // binary
let h:number=0x27AD;   // hexadecimal
let o:number=0o2703    // octal
console.log(b,h,o); // 58 10157 1475

1.What all types of values a number can store in TypeScript?
In JavaScript / TypeScript, all the below fall under the number/numeric category 
   Number/ numeric value 
   Float value 
   Hexadecimal 
   Binary 
   Octal
It's not like a traditional programming language like integer, double or may be float TypeScript is considering JavaScript as base, so it's going to follow the same rules

2.How will you store a binary or hex value in TypeScrlpt? 
let b:number=0b111010; // binary
let h:number=0x27AD;   // hexadecimal
let o:number=0o2703    // octal
console.log(b,h,o); // 58 10157 1475
We use these different types in TypeScript in the same way we use in JavaScript

2.Boolean :
A boolean variable contains true / false values Similar to JavaScript, the value you assign to a boolean variable has to be true / false in lower case
With boolean variables, there is a logical operator provision, you can use '!' to negate it.
let a:boolean=true
let b:boolean=!false
console.log(!a); // false
console.log(b);  // true
1.What will be the output of below given code? 
let a:boolean = !true; 
console.log(!a)
Ans : true

3.Null, undefined, void : 
Whenever you declare a variable in JavaScript, it is treated as undefined. undefined is the data type, "undefined" means the variable is written there but there is no existence of it in the memory. By default, any variable declared in TypeScript (like JavaScript) is going to be "undefined".
let a:number;
console.log(typeof a) // undefined
Empty string is not undefined in typescript, it is treated as string.
let a:string='';
console.log(typeof a) // undefined

undefined is data type itself, null actually treated as an object. But if we try to apply Primitive operation on null it will be treated as zero instead of treating as an object.
let a: string | undefined;
a = 'vbn'
console.log(a) // vbn

null is a primitive type in TypeScript. You can explicitly declare a variable as null: 
   let x: null = null 
It is valid but not useful because you can not assign any data type to x later, since strictNullChecks is enabled by default.
Correct Approach is : Best practise to assign null to a variable is using pipe '|' operator (used for type safety)
Using the pipe (|) operator to combine null with another data type is a better approach because it allows flexibility while keeping type safety.
   let username: null; // ❌
   let username: null = null // ❌
   let username: string | null = null; // ✅
   console.log(username) // it will assign default null
   username = 'vai'      
   console.log(username) // vai
IMP : Whenever using null or undefined combine it with another data type, as strictNullChecks is enabled by default.
   let a: null // ❌
   let a: null = null  // ❌ 
   let a: number | null = null  // ✅
   a = 6
   let b: number=5;
   let c: undefined
   console.log(a+b) // 11
   console.log(b+c) // NaN 'c' is possibly 'undefined'

In traditional programming language like C & C++, Whenever you write a function, it has a return type. In typescript you can also decide the return type of the function also using void. void means nothing. You use void when the function is not going to return any values.
We must define return type of the function in typescript. Return type is the type of value the function is going to return after the operation is done.
function sum(a:number, b:number):number {
  return a + b;
}
console.log(sum(6, 7))
In JavaScript by default any function returns undefined. If you do not write return statement at the end of the function all JavaScript functions by default return undefined.
In JavaScript :
function test() {
  console.log('nothing to return')
}
console.log(test()) // nothing to return & undefined
In TypeScript when we define return type, it means you are fixing that function will return specific type of value. But if a function is not returning any type of value or it does not have the return statement at the end then you must use 'void' as return type.
"void" is a kind of datatype which says that there is nothing to return / assign in the function.

1.Explain the difference between null & undefined.
Null is assignable value whereas we don't need to assign undefined as any variable we declare by default it is undefined.
JavaScript implicitly converts null to 0 in arithmetic operations. TypeScript does not allow arithmetic with null as strictNullChecks is enabled by default. null is falsy in logical operations, but not equal to 0 (null == 0 → false).
undefined + number → Results in NaN in both Typescript & JavaScript
   console.log(undefined + 5) // The value 'undefined' cannot be used here. 
   console.log(null + 5) // The value 'null' cannot be used here.
Typescript does not allow any operation with undefined or null unless you explicitly convert them to number.
   console.log(Number(undefined) + 5) // NaN
   console.log(Number(null) + 5)  // 0 + 5 = 5
2.When do you need the void datatype?
A function which does not return any type of value, then in such cases we use the void datatype.

4.any :
"any" is one datatype in TypeScript, which can hold any type of value If you don't specify the type, it will be considered as "any". When we declare variable without specifying data type, typescript assigns it 'any' data type. It means variable can have any type of value.
By default, whenever you declare a variable in JavaScript, it can hold any type of value.
TypeScript assigns the any type to a when declared without an explicit type or initialization.
   let a;  // any data type is assigned by default
   let a: any; // any data type is assigned explicitly
   console.log(typeof a); // undefined

1.When do you think "any" type is useful in your code? 
"any" is often used when you don't know which type of value will be assigned to a variable in future E.g., You have data returning from 3rd party APls, & you want to avoid TypeScript compile time error, then you declare a variable as "any" This is a common practice we see when we are not sure about what type of value will be returned into a variable.

5.Type annotation & Type inference : It means fixing the data type while declaring variable. With the colon (:) sign we explicitly annotate the data type. 
When we can declare variable without data type but typescript will assign 'any' data type to that variable. We mostly use 'any' data type when you don't know which type of value will be assigned to a variable in future.
When we can declare variable & assign value to it without using type annotation (without specifying data type), the typescript compiler infers or assumes the type according to assigned value. This is called as the inference means typeScript infers or assumes the type depending on the assigned value.
let x=3; 
console.log(typeof x) // number
let a = 'vbn'
console.log(typeof a) // string
a = 4  // Error Type 'number' is not assignable to type 'String'
Depending on the type of value assigned to a variable, TypeScript infers / assumes / decides the datatype as well.

1.When does TypeScript infers the datatype ?
There are various situations where, even though we have not given the type annotation that is not explicitly defined the datatype the typeScript infers (assumes) the datatype.
There are 3 situations which i can explain :
   1.TypeScript infers or assumes the datatype when you assign value to the variable without specifying data type. For example let x=4. Here the value assigned to variable is number so typeScript infers that x is of data type number.
   2.When assigning default values to the function parameters, Typescript automatically infers or the data type of the parameters.
   function sum(a=4, b=5){
      return a + b
   } 
   3.When a function is returning a specific type of value or function has specific return type & we assign that returned value to the variable then typeScript will treate variable as that type.
   function sum(a = 3, b = 5): number {
      return a + b;
   }
   console.log(sum()); // 8
   let a = sum(6, 7); 
   console.log(typeof a); // number 
   Here typescript will assign number data type to the variable 'a'

6.Hoisting, function scope, block scope :
Scope : Scope of variable means its the lifetime or availability of the variable. If you declare a variable in one function then it won't be available in the other function. Scope of variable can be local or global. When we declare variable inside a function it is local to that function. To declare the variable as global we declare it ouside all the functions.
   let x: number = 10
   function a(): number {
      x = x + 5
   }
   function b(): number {
      console.log(x)
   }
   console.log(a()) // undefined 15
   console.log(b()) // 10 undefined


Block Scope : A variable is block-scoped when it is accessible only within the block {} where it is declared. Variables declared with "let" and "const" have block scope. Accessing them outside the block results in a ReferenceError.

Function Scope : A variable is function-scoped when it is accessible throughout the function in which it is declared. Variables declared with "var" have function scope. Accessing them outside the function results in a ReferenceError

Hoisting :  Hoisting is a JavaScript mechanism where variable and function declarations are moved to the top of their scope before execution.
   In case of variable declared with "var" only declarations are hoisted but initialization do not hoisted, that means variable initialized with undefined.
   In the case of a variable declared with let or const, both the declaration and initialization are not hoisted, meaning the variable remains in the Temporal Dead Zone (TDZ) until it is assigned a value. Accessing it before declaration results in a ReferenceError.
   When we try to access a variable declared with var before its declaration, it results in undefined due to hoisting.
   When we try to access a variable declared with let before its declaration, it results in a ReferenceError due to the Temporal Dead Zone (TDZ).
   When we try to access a variable declared with const before its declaration, it results in a ReferenceError due to the Temporal Dead Zone (TDZ).

console.log(y) // ReferenceError: y is not defined
console.log(x) // undefined
var x=9;
console.log(a) // ReferenceError: Cannot access 'a' before initialization
let a;
console.log(b) // SyntaxError: Missing initializer in const declaration
const b

7.String :
let a:string = 'I'm not new to TS'
console.log(a) // SyntaxError: Invalid or unexpected token
To correct this either we use double quotes or escape character "\"
let a:string = "I'm not new to TS"
console.log(a) // I'm not new to TS
let a:string = "I\'m not new to TS"
console.log(a) // I'm not new to TS
let a:string = "I\'m not \n new to TS"  // newline
let a:string = "I\'m not \t new to TS"  // tab

\b Backspace   \v Vertical Tab
\f Form feed   \u For unicode
\n New line    \' Display'
\r Carriagereturn \" Display "
\t Horizontal tab \\ Display\

When you want to diplay \ in sentence
let a:string = 'I'm not \new to TS'
console.log(a) 
// I'm not 
ew to TS
let a:string = 'I'm not \\new to TS'
console.log(a)  // I'm not \new to TS

8.Unicode values with string data type :
\u is an escape sequence which will allow you to work with unicode characters. The string datatype is stored in UTF-16 format. In case if there is a special character to be displayed then unicode is represented with a 4—digit hexadecimal number. To display this character you can use \uHHHH where H is the 4—digit hexadecimal number.
For example : Hex value for '©' sign is 00A9. 
let a:string = "00A9"
console.log(a) // 00A9
let a:string = "\u00A9"  // we have used \u to print hex value ©
console.log(a) // © 
When you have hex value more than 4 digits we use curly brackets 
let a:string = "\u{1F601}"
console.log(a) // 😁
The range for emoji is 1F601 to 1F64F

1.How to deal with Unicode characters?
We can use \u for dealing with unicode characters & for long unicode characters (more than 4 words) we use curly brackets.

9.Type aliases : You can define custom data type in typescript using type aliases.
Type aliases in TypeScript are used to declare custom data types. They allow you to define complex, reusable types with a custom name.
type Address = {
  Street: string,
  City: string,
  PinCode: number
}
function showData(obj:Address){
  console.log(obj.Street, obj.City, obj.PinCode)
}
console.log(showData({Street:'my', City:'your', PinCode: 123})) // my your 123 undefined

You can use a union type with a type alias by using the pipe operator (|) to allow multiple data types.
   The pipe operator (|) allows defining multiple data types in a Type Alias.
   It improves code reusability and type safety.
   Used for variables, function parameters, and object properties.
      type Pincode = number | string;
      let p :Pincode;
      p = 'Test'
      console.log(p)
      p = 123
      console.log(p)

1.How can you define your own or custom datatype?
We can define custom data type using type alias, the "type" keyword is used to do so.


10.never :
In bigger applications, we sometime create functions which handle the errors & this type of functions never return anything, these functions are only used to generate errors.
It means that the function does not finish the process & breaks / crashes in between in a way because there will be a throw statement. It never returns anything, you can set "never" as a return type for such functions.
never Vs void :
never :
   Used for functions that never return anything for example function that throws an error or function with infinite loop
   The function never reaches the end & never return anything
   Use never for functions that always throw errors or run indefinitely.
void :
   Used for functions that return nothing for example logging functions
   The function returns undefined
   Use void for functions that don’t return meaningful values (e.g., logging, event handlers)
Examples :
   1.never Example: Function That Throws an Error
   function throwError(message: string): never {
      throw new Error(message);
   }

   try {
      throwError("Something went wrong!"); // Always throws an error
   } catch (error) {
      console.error("Caught error:", error);
   }
   ✅ Handling Strategy: Use try...catch to catch the error and prevent program crashes.
   2.never Example: Function With an Infinite Loop
   function infiniteLoop(): never {
     while (true) {
       console.log("Running forever...");
      }
   }
   ❌ No handling needed because this function never stops executing.
   3.void Example: Logging Function
   function logMessage(): void {
     console.log("Logging information...");  
   }
   logMessage(); // ✅ Allowed, prints message
   ✅ Handling Strategy: void functions return undefined, so avoid assigning their return value to variables.
   4.void Example: Event Handler
   function handleClick(): void {
     console.log("Button clicked!");
   }
   document.getElementById("myButton")?.addEventListener("click", handleClick);
   ✅ Handling Strategy: No handling required, as the function simply logs an action.

void means “no return value”, which is similar to undefined. If strictNullChecks is enabled, null is not allowed.
never means “a value that will never exist”. You cannot assign anything to never, because it represents an impossible state.

1.What is "never" type? Explain with an example
When you have situations like raising an error or inifinite loop, these kind of functions which never ends & breaks in between in such cases use never.
function raiseError(eN:number, eD:string){
    throw{
        errNumber: eN,
        errDesc: eD
    }
}
raiseError(14, 'Invalid User') // {errNumber: 14, errDesc: 'Invalid User'}
2.What is the difference between "void" & "never" type?
You can assign undefined to void (always), and null if strictNullChecks is false. However, you cannot assign null or undefined to never. Check above


To run typescript file we use : tsc app.ts
For automatically run typescript file on changes : tsc app.ts --watch OR tsc app.ts -w
Watch mode used for hot reloading your typescript file.
Watch mode can keep a watch on individual file, and whenever there is a change made, it will compile it automatically as a JavaScript file.
1.What is the watch mode and how can you run TypeScript compiler in the watch mode?
   by using --watch or -w parameter

Watch mode for entire project :
   tsc --init  : used to initiate the project
   it will create tsconfig.json
   tsc -w
To exclude files from typescript compilation : 
   open tsconfig.json & after second last curly bracket add comma & following code :
      "exclude" : [ "product.ts", "node_module", "*.dev.ts" ]   
   Compiler will not watch for product.ts or it does not compile it. Also we can give folder name in that array like node_module. You can use wildcard * for multiple files
To automatically exclude other files from compilation :
   "include" : ["app.js", "product.ts"]
   Now typescript will only compile these two files, excluding all other files in the project

1.What is the use of tsconfigjson file and how do you create it?
The tsconfig.json file contains the configuration related to the entire project. To create this file we use tsc --init command. 
2.How can you run a specific file in a watch mode ?
Whenever there are changes in the file, & you don't want to stop and re-run the TypeScript compiler, use watch mode —> tsc -w. Watch mode automatically run the typeScript compiler on changes in file
3.How can you avoid selected files from getting compiled?
In tsconfig.json add entry in exclude or include array. "exclude" is an array that can hold a list of files that you want to avoid from compiling when the tsc is running.

Setting compilation target :
In tsconfig.json we have key or property named compilerOptions, which contains multiple options for compilation.
Options in compilerOptions :
1.targat option :
The target option basically decides that the code converted by TypeScript compiler should be in which version of JavaScript
for es5 code -> "target": "es5"  
for es6 code -> "target": "ES2015"  
2.lib option :
JavaScript & Browser APIs including DOM are available in TypeScript by default. In default settings lib is commented & all these are available by default. It also depends on target you selected before.
"lib": ["ES5", "DOM"]
When installing TypeScript, it comes with :—
   JavaScript APIs like Array.prototype.map, promise etc.
   Browser APIs such as the DOM, setTimeout, fetch API, Webworker or console.log etc
These library references are installed under the src/lib folder in the lib directory of TypeScript installation
By default, depending on the target option, libraries are included E.g. If you set the target to ES5, then certainly Promise will not be available as it was introduced in the ES2015 i.e ES6.
So when you set the libraries, you have to take care of all related APIs you use. If they are not set — then by default, it generally takes care of the project and project configuration

What is the purpose of the "lib" option?
So the "lib" option allows you to set the library i.e all the APIs you want to use. The list of APIs available on git repository.

What will be the default value of the "lib" option?
It mainly depends on the target if the target is not set then by default, it includes almost everything. If you want to manually add a few additional libraries, you can write that list in the "lib" option.

3.module option : Defines how TypeScript handles modules (import/export).
   "CommonJS" – Used in Node.js
   "ES6" – Used in modern browsers
   "AMD" – Used in RequireJS
   "ESNext" – Supports the latest ES module features
   {
     "compilerOptions": {
      "module": "ES6"
      }
   }
4.outDir option : Specifies where the compiled JavaScript files should be saved.
   {
     "compilerOptions": {
     "outDir": "./dist"
      }
   }
5.outFile : Combines multiple TypeScript files into one JavaScript file. Instead of multiple .js files, it creates one single bundle.js.
{
  "compilerOptions": {
    "module": "AMD",
    "outFile": "./dist/bundle.js"
  }
}
6.rootDir : Defines the source directory for TypeScript files.
{
  "compilerOptions": {
    "rootDir": "./src",
    "outDir": "./dist"
  }
}
7.removeComments & noEmit : 
   removeComments: Removes all comments in the compiled code
   noEmit: Prevents TypeScript from generating JavaScript files. The TypeScript compiler will check for errors, but it won’t generate JavaScript files. Useful if you only want to check for errors without outputting .js files.
{
  "compilerOptions": {
    "removeComments": true
  }
}
{
  "compilerOptions": {
    "noEmit": true
  }
}
8.sourceMap - Generating Source Maps : Creates .map files to debug TypeScript in the browser.
Helps browsers map .js code back to TypeScript for debugging. In Chrome DevTools, you will see TypeScript files instead of JavaScript.
{
  "compilerOptions": {
    "sourceMap": true
  }
}
9.inlineSources - Include Source Code in Source Maps : Embeds TypeScript directly inside the .map file. Useful when debugging without access to the original .ts files.
{
  "compilerOptions": {
    "sourceMap": true,
    "inlineSources": true
  }
}
To apply these settings, create a tsconfig.json file and run : tsc 

Arrays & Tuples :
Array : An array is a collection of values of the same type.
let numbers: number[] = [1, 2, 3, 4, 5];
let names: string[] = ["Alice", "Bob", "Charlie"];
console.log(numbers[0]); // Output: 1
console.log(names.length); // Output: 3
Modify Arrays :
push() – Add an element at the end.
pop() – Remove the last element.
unshift() – Add an element at the beginning.
shift() – Remove the first element.

Tuple : A tuple is an ordered array with a fixed number of elements, each with a specific type.
let user: [string, number] = ["Alice", 25];
console.log(user[0]); // Output: Alice
console.log(user[1]); // Output: 25
The first element must be a string, and the second must be a number.

Union Type : A Union Type allows a variable to hold multiple types.
let value: string | number;
value = "Hello";  // ✅ Allowed
value = 42;       // ✅ Allowed
// value = true;  ❌ Error: Only string or number allowed

Narrowing & Type Guards : TypeScript automatically detects the exact type inside a condition. typeof helps TypeScript narrow down the correct type.
function printLength(value: string | number) {
  if (typeof value === "string") {
    console.log(value.length); // ✅ TypeScript knows it's a string
  } else {
    console.log(value.toFixed(2)); // ✅ TypeScript knows it's a number
  }
}
printLength("Hello"); // Output: 5
printLength(42.567); // Output: 42.57

map() Method : Creates a new array by applying a function to each element. Returns a new array without changing the original.
let numbers: number[] = [1, 2, 3];
let squared = numbers.map(num => num * num);
console.log(squared); // Output: [1, 4, 9]

reduce() & reduceRight() : reduce() – Reduces an array from left to right. reduceRight() – Reduces an array from right to left.
let nums: number[] = [1, 2, 3, 4];
let sum = nums.reduce((acc, num) => acc + num, 0);
console.log(sum); // Output: 10
let product = nums.reduceRight((acc, num) => acc * num, 1);
console.log(product); // Output: 24

Multidimensional Array : An array of arrays.
let matrix: number[][] = [
  [1, 2, 3],
  [4, 5, 6],
  [7, 8, 9]
];
console.log(matrix[1][2]); // Output: 6

